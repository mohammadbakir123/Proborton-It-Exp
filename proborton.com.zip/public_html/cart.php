

 
 

 <?php 
 
session_start();
error_reporting(0);

   $active='Cart';

 ?>


 






 <?php include("includes/db_cons.php");
 ?>
 



 
 
 
 <?php 
 include("function/function.php");



 ?>




</br>
</br>
</br>
</br>
  



  <body> 

</br></br></br>


       

<div class="aa-product-catg-body">


  

           
           <div id="cart" class="col-md-9">
               
               <div class="box">
                   
                   <form action="cart.php" method="post" >
                       
                       <h1>Order List </h1>
					   <?php 
					   $ip_add = getRealIpUser();
					   $select_cart ="select * from cart where ip_add ='$ip_add'";
					   $run_cart =mysqli_query($con,$select_cart);
					   $count =mysqli_num_rows($run_cart);
					   
					   ?>
                     
                       
                       <div class="table-responsive">
                           
                           <table class="table">
                               
                               <thead>
                                   
                                   <tr>
                                       
                                       <th colspan="2">product</th>
                                        
                                       <th>Amount </th>
                                       <th> Fixed Price</th>
                                       <th> Size</th>
                                       <th colspan="1">Delete </th>
                                       <th colspan="2">Sub total </th>
                                       
                                   </tr>
                                   
                               </thead>
                               
                             
                          
                               
                               <tbody>
							   <?php
							   
							     $total = 0;
							    while($row_cart = mysqli_fetch_array($run_cart)){
								 $pro_id = $row_cart['p_id']; 
								 $pro_size = $row_cart['size']; 
						         $pro_qty = $row_cart['qty']; 
							     $get_products ="select * from  products where product_id='$pro_id'";
								 $run_products = mysqli_query($con,$get_products);
								 while($row_products = mysqli_fetch_array($run_products)){
								$product_title = $row_products['product_title'];
								$product_img1 = $row_products['product_img1'];
                                $only_price = $row_products['product_price'];    									
								$sub_total = $row_products['product_price']* $pro_qty;	 
								 $total +=$sub_total;
							   
							   
							   ?>
                                   
                                   <tr>
                                       
                                       <td>
                                           
                                           <img class="img-responsive" src="proimage/<?php echo $product_img1;?>" alt="Product 3a">
                                           
                                       </td>
                                       
                                       <td>
                                           
                                           <a href="details.php?pro_id=<?php echo $pro_id;?>"><?php echo $product_title;?> </a>
                                           
                                       </td>
                                       
                                       <td>
                                          
                                          <?php echo $pro_qty;?>
                                           
                                       </td>
                                       
                                       <td>
                                           
                                         <?php echo $only_price;?>
                                           
                                       </td>
                                       
                                       <td>
                                           
                                          <?php echo $pro_size;?>
                                           
                                       </td>
                                       
                                       <td>
                                           
                                           <input type="checkbox" name="remove[]" value=" <?php echo $pro_id;?>">
                                           
                                       </td>
                                       
                                       <td>
                                           
                                           <?php echo $sub_total;?>
                                           
                                       </td>
                                       
                                   </tr>
								   <?php }}?>
                                   
                               </tbody>
                               
                               <tfoot>
                                   
                                   <tr>
                                       
                                       <th colspan="5">Total</th>
                                       <th colspan="2">৳<?php echo $total;?></th>
                                     
                                   </tr>
                                   
                               
                                   
                               </tfoot>
                               
                           </table>
                           
                    
                       
                       <div class="box-footer">
                           
                           <div class="pull-left">
                                     <div class="pull-left">
                               
                               <a href="index.php" class="btn btn-default">
                                   
                                 Home 
                                   
                               </a>
                               
                           </div>
                           
                             
                           </div>
                           
                           <div class="pull-right">
                               
                               <button type="submit" name="update" value="Update Cart" class="btn btn-default">
                                   
                                   <i class="fa fa-refresh"></i> Delete
                                   
                               </button>
                           
                               
                           </div>
                           
                       </div>
                          </div>
                   </form>
                   
               </div>
			   
			   
			   <?php 
			   function update_cart(){
				   global $con;
				   if(isset($_POST['update'])){
					 foreach($_POST['remove'] as $remove_id){
						 $delete_product ="delete from cart where p_id='$remove_id'";
						 $run_delete = mysqli_query($con,$delete_product);
						 if($run_delete){
							 echo "<script>window.open('cart.php','_self')</script>";
						 }
					 }
				   }
				   
			   }
			   
			   
			   
			   echo @$up_cart =update_cart();
			   
			   ?>
               
        
           </div>
             
           <div class="col-md-3">
             
               <div id="order-summary" class="box">
                   
              
                   
            
                   
                   <div class="table-responsive">
                       
                       <table class="table">
                           
                           <tbody>
                               
                               <tr>
                                   
                                   <td> Order Sub-Total </td>
                                   <th> </th>
                                   
                               </tr>
                               
                               <tr>
                                   
                                   <td> Shipping and Handling </td>
                                   <td>    ৳0 </td>
                                   
                               </tr>
                               
                               <tr>
                                   
                                   <td> Tax </td>
                                   <th>    ৳0 </th>
                                   
                               </tr>
                               
                               <tr class="total">
                                   
                                   <td> Total </td>
                                   <th> ৳<?php echo $total;?> </th>
                          
                          
                          
                               <tr>  </tr>
                               
                          
                               
                          <td>   <a href="checkout.php" class="btn btn-success"> Process  checkout   </a> </td>  </tr>
                               
                           </tbody>
                           
                       </table>
                       
                   </div>
                   
               </div>
               
           </div>
           
       </div>
   <style>
       
     
       
   </style>

 
    <!-- Main style sheet -->
   
     <meta name="viewport" content="width=device-width, initial-scale=1">
 
       <!-- Google Font -->
    <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
    <script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
    
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
       <link rel="stylesheet" href="styles/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">

 
 
 
 
 
    <link rel="stylesheet" href="style.css" />

   <link rel="stylesheet" href="styles/bootstrap-337.min">
     <link href="css/style.css" rel="stylesheet">   
    <!-- Google Font -->
    <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
    
 <!-- AOS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
  <!-- Gsap -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>
  <!-- Glidejs -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/glide.min.js"></script>
  <!-- Custom Script -->
  <script src="./js/slider.js"></script>
  <script src="./js/index.js"></script>
  <script src="/path/to/cdn/jquery.min.js"></script>
<script src="/path/to/jquery.scrollimageinside.js"></script>

<script>
   $( window ).on( 'load', function(){
   $( '.screen' ).scrollImage();
   })
</script>


<script>
$('#example').scrollimageinside({
  speed: 900
});
</script>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>
    
    

	

  
   
  </body>
  
   
  
</html>
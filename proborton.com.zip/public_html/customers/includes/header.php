

 <?php 
 
include("function/function.php");

include("include/db_cons.php");
 ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
    <meta name="description" content="Proborton is one of the leading Information Technology Solution Companies in Proborton specializes in development of complex software systems" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <meta property="og:image" content="https://www.proborton.com/images/d.jpg">
  <!-- Favicon -->
  <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" />
  <!-- AOS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
  <!-- Glidejs -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.core.css" />
  <style>







  </style>
  
  
  <script src="https://code.jquery.com/jquery-1.12.4.min.js" 
        integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" 
        crossorigin="anonymous">
</script>
<script src="jquery-image-scroll.js"></script>
  <!-- Custom Stylesheet -->
  <link rel="stylesheet" href="./styles.css" />
  <title>Proborton-IT-Exp</title>
   <link rel="stylesheet" href="style.css" />
    
    <!-- Bootstrap -->
    
</head>

<body>






<!-- header file -->




  <header id="header" class="header">
    <!-- Navigation -->
    <div class="navigation">
      <nav class="nav d-flex container">
        <div class="nav-header d-flex">
          <div class="logo"><a href="../index.php" >
          <h1>Proborton<span>IT</span>Exp</h1> </a>
          </div>

          <div class="hamburger"><i class="fas fa-bars"></i></div>
        </div>

        <div class="nav-menu d-flex">
          <ul class="nav-list d-flex">
            <li class="nav-item">
                
                
   
                
                  
              <a href="../index.php" class="nav-link">Home</a>
              
                 </li>
              <li class="nav-item"> 
             
              <a href="../customer_register.php" style="color:white; font-size:14px; font-weight: bold; " >SIGN UP</a>
              
              
            </li>
          
                   
          
          
          
          
          
            <li class="nav-item">
              <a href="../#about" class="nav-link scroll-link">About</a>
            </li>

            <li class="nav-item">
              <a href="../#services" class="nav-link scroll-link">Services</a>
            </li>

            <li class="nav-item">
              <a href="../#portfolio" class="nav-link scroll-link">Portfolio</a>
            </li>

            <li class="nav-item">
              <a href="../#testimonial" class="nav-link scroll-link">Testimonial</a>
          </li>

            <li class="nav-item">
              <a href="../#contact" class="nav-link scroll-link">Contact</a>
            </li>


                 <li class="nav-item" style="color:white;"> 
                   <a href="../checkout.php">
                          <?php 
                           
                                 if(!isset($_SESSION['customer_email'])){
                       
                                echo "<a href='../checkout.php' style='color:white; font-size:14px; font-weight: bold;'> LOGIN </a>";

                               }else{

                                echo " <a href='logout.php'>LOGOUT </a> ";

                               }
                           
                           ?>
                     </a>
                   </li>

	                     

          </ul>
        </div>
      </nav>
    </div>

    <!-- Hero Content -->
    
    
    


  </header>
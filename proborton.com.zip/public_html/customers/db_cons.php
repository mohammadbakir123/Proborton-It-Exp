 
 <?php
$con = mysqli_connect("localhost","u401587422_myuser","Gt7dFo1fM!","u401587422_mydb");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>

 
 

 <?php 
 
session_start();
error_reporting(0);



 ?>



 <?php include("includes/db_cons.php");
  
 
 
 
 ?>
   




 <?php 
 
include("function/function.php");

include("includes/db_cons.php");
 ?>
 
 
 
	<?php 



if(isset($_GET['pro_id'])){
    
    $product_id = $_GET['pro_id'];
    
    $get_product = "select * from products where product_id='$product_id'";
    
    $run_product = mysqli_query($con,$get_product);
    
    $row_product = mysqli_fetch_array($run_product);
    
    $product_id = $row_product['product_id'];
    
    $pro_title = $row_product['product_title'];
    
    $pro_price = $row_product['product_price'];
    
    $pro_desc = $row_product['product_desc'];
    
    $pro_img1 = $row_product['product_img1'];
    
    $pro_img2 = $row_product['product_img2'];
    
    $pro_img3 = $row_product['product_img3'];
	
        
  
    
}

?>



 

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
    <meta name="description" content="Proborton is one of the leading Information Technology Solution Companies in Proborton specializes in development of complex software systems" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <meta property="og:image" content="https://www.proborton.com/images/d.jpg">
  <!-- Favicon -->
  <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" />
  <!-- AOS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
  <!-- Glidejs -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.core.css" />
  
   <link rel="stylesheet" href="style.css" />
  <style>







  </style>
  
  
  <script src="https://code.jquery.com/jquery-1.12.4.min.js" 
        integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" 
        crossorigin="anonymous">
</script>
<script src="jquery-image-scroll.js"></script>
  <!-- Custom Stylesheet -->
  <link rel="stylesheet" href="./styles.css" />
  <title>Proborton-IT-Exp</title>
   <link rel="stylesheet" href="style.css" />
    
    <!-- Bootstrap -->
    
</head>

<body>






<!-- header file -->




  <header id="header" class="header">
    <!-- Navigation -->
    <div class="navigation">
      <nav class="nav d-flex container">
        <div class="nav-header d-flex">
          
              <div class="logo" ><a href="../index.php">
          <p>   Proborton-It-Exp  </p></a>
          </div>
          
          
         
          <div class="hamburger"><i class="fas fa-bars"></i></div>
       
        </div>

        <div class="nav-menu d-flex">
          <ul class="nav-list d-flex">
      
              <li class="nav-item"> 
             
              <a href="../customer_register.php" style="color:white; font-size:14px; font-weight: bold; " >SIGN UP</a>
              
              
            </li>
          
                   
          
          
          
          
          
            <li class="nav-item">
              <a href="../#about" class="change">About</a>
            </li>

            <li class="nav-item">
              <a href="../#services" class="change">Services</a>
            </li>

            <li class="nav-item">
              <a href="../#portfolio" class="change">Portfolio</a>
            </li>

     

            <li class="nav-item">
              <a href="../#contact" class="change">Contact</a>
            </li>


                 <li class="nav-item" style="color:white;"> 
                   <a href="../checkout.php">
                          <?php 
                           
                                 if(!isset($_SESSION['customer_email'])){
                       
                                echo "<a href='checkout.php' style='color:white; font-size:14px; font-weight: bold;'> LOGIN </a>";

                               }else{

                                echo " <a href='logout.php'>LOGOUT </a> ";

                               }
                           
                           ?>
                     </a>
                   </li>

	                     

          </ul>
        </div>
      </nav>
    </div>

    <!-- Hero Content -->
    
    
    


  </header>
    
  <body> 

</br>
</br>
</br>
</br>

   <div class="jquery-script-center">
<div class="center"
	
	   
   <p > <a class="text-right" href="cart.php"> <?php total_price();?> || <i class="fa fa-shopping-basket" aria-hidden="true"></i></a></p>
	  
				     
				      <ul>
				
				
              
                 
				  
				
				    <?php add_cart(); ?>
				     <form action="view.php?add_cart=<?php echo $product_id; ?>" class="form-horizontal" method="post"><!-- form-horizontal Begin -->
                             
							 <div class="form-group"><!-- form-group Begin -->
                                <p class="text-left "><button class="btn"> Add to cart</button></p>
                            
                                   <div class="col-md-2 col-sm-2"><!-- col-md-7 Begin -->
                                          <select name="product_qty" id="" class="btn2"><!-- select Begin -->
                                           <option>1</option>
                                           <option>2</option>
                                           <option>3</option>
                                           <option>4</option>
                                           <option>5</option>
                                           </select><!-- select Finish -->
                                   
                                    </div><!-- col-md-7 Finish -->
                                   
                               </div><!-- form-group Finish -->
                               
                                    
                      </ul>
                        
                               
                              
                               
                           </form><!-- form-horizontal Finish -->
		
				  
                 
				  
                </div>
          
    
            </div>
                    
                
                     </br>
                     </br>
                     </br>
                     </br>
                               
           
 <div class="col-sm-12 col-md-12 col-xs-12"><!-- col-md-9 Begin -->
         
             
             
               <div id="productMain" class="row"><!-- row Begin -->
                   <div class="col-md-12"><!-- col-sm-6 Begin -->
                  
                       <div id="mainImage"><!-- #mainImage Begin -->
                       
                     
                       
             <div id="myCarousel" class="carousel slide" data-ride="carousel"><!-- carousel slide Begin -->
             
             
                                    
             
             
             
             
             
                      <ol class="carousel-indicators"><!-- carousel-indicators Begin -->
                      <li data-target="#myCarousel" data-slide-to="0" class="active" ></li>
                      <li data-target="#myCarousel" data-slide-to="1"></li>
                      <li data-target="#myCarousel" data-slide-to="2"></li>
                               </ol><!-- carousel-indicators Finish -->
                           
                               
                               <div class="carousel-inner">
                              
                             
                              
                              
                              
                                   <div class="item active">
                                       <center><img class="img-responsive" src="proimage/<?php echo $pro_img2; ?>" alt="Product 3-b"></center>
                                   </div>
                                   </br>
                                   </br>
                                   </br>
                                   <div class="item">
                                       <center><img class="img-responsive" src="proimage/<?php echo $pro_img3; ?>" alt="Product 3-c"></center>
                                   </div>
                               </div>
                           
                  
                           </div><!-- carousel slide Finish -->
                      
                       </div><!-- mainImage Finish -->
                   </div><!-- col-sm-6 Finish -->
                   

                   
               </div><!-- row Finish -->
			      <a href="#myCarousel" class="left carousel-control" data-slide="prev"><!-- left carousel-control Begin -->
                                   <span class="glyphicon glyphicon-chevron-left"></span>
                                   <span class="sr-only">Previous</span>
                               </a><!-- left carousel-control Finish -->
                               
                               <a href="#myCarousel" class="right carousel-control" data-slide="next"><!-- right carousel-control Begin -->
                                   <span class="glyphicon glyphicon-chevron-right"></span>
                                   <span class="sr-only">Previous</span>
                               </a><!-- right carousel-control Finish -->


    </div>
  
 <style>
 
 
   .btn{
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
       
       
   }
 
        .btn2{
  background-color: gray;
  border: none;
  color: white;
  padding: 15px 45px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
        margin-left:-6px;
       
   }
    .text-left{
        margin-left:20px;
        
       
    }
    .text-right{
        
          margin-left:40px;
           background-color: #4CAF50;
  border: none;
  color: white;

  text-align: center;
   text-decoration: none;
  display: inline-block;
  font-size: 16px;

  cursor: pointer;
   position:static;
  

    }
    

         
  .col-md-2{
      
 
     
    margin-left:20px;
         
         
     }
     
         .col-sm-2{
      
      width:15px;
      
  
         
         
     }
     
        .logo p{
            
            color:white;
            font-size:24px;
            font-weight:bold;
            
           
        }
        .logo{
            
          
           
        }

     .change{
      padding: 1rem;
  color: var(--white);
  font-size: 1.4rem;
  font-weight: 600;
  text-transform: uppercase;
  transition: all 0.3s ease-in-out;
}


 .nav-item{
     
     margin-right:-5px;
     position: static;
     
 }

  .jquery-script-center{
      
      margin-left:70px;
  }
     
 </style>
 

 <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">

    <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
    <script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
    
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
  

 <!-- AOS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
  <!-- Gsap -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>
  <!-- Glidejs -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/glide.min.js"></script>
  <!-- Custom Script -->
  <script src="./js/slider.js"></script>
  <script src="./js/index.js"></script>
  <script src="/path/to/cdn/jquery.min.js"></script>
<script src="/path/to/jquery.scrollimageinside.js"></script>

<script>
   $( window ).on( 'load', function(){
   $( '.screen' ).scrollImage();
   })
</script>


<script>
$('#example').scrollimageinside({
  speed: 900
});
</script>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

  </body>
  
   
  
</html>



  

<?php

   $active='Account';

?>



 <?php 
 
include("function/function.php");

include("includes/db_cons.php");
 ?>
 
 
 
	<?php 



if(isset($_GET['pro_id'])){
    
    $product_id = $_GET['pro_id'];
    
    $get_product = "select * from products where product_id='$product_id'";
    
    $run_product = mysqli_query($con,$get_product);
    
    $row_product = mysqli_fetch_array($run_product);
    
    $product_id = $row_product['product_id'];
    
    $pro_title = $row_product['product_title'];
    
    $pro_price = $row_product['product_price'];
    
    $pro_desc = $row_product['product_desc'];
    
    $pro_img1 = $row_product['product_img1'];
    
    $pro_img2 = $row_product['product_img2'];
    
    $pro_img3 = $row_product['product_img3'];
	
        
  
    
}

?>
	



  <section id="aa-product-details">



   <div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
        
           
           <div class="col-md-12"><!-- col-md-12 Begin -->
           
                <?php 
                
                if(!isset($_SESSION['customer_email'])){
                    
                    include("customer_login.php");
                    
                }else{
		
		           include("payment_options.php");
		
	}
	
                
                ?>
           
           </div><!-- col-md-12 Finish -->
           
       </div><!-- container Finish -->
   </div><!-- #content Finish -->
   
     </section>






<script>
   $( window ).on( 'load', function(){
   $( '.screen' ).scrollImage();
   })
</script>


<script>
$('#example').scrollimageinside({
  speed: 900
});
</script>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>






        <div class="nav-menu d-flex">
          <ul class="nav-list d-flex">
            <li class="nav-item">
                
                
   
                
                  
              <a href="/" class="nav-link">Home</a>
              
                 </li>
              <li class="nav-item"> 
             
              <a href="../customer_register.php" style="color:white; font-size:14px; font-weight: bold; " >SIGN UP</a>
              
              
            </li>
          
                   
          
          
          
          
          
            <li class="nav-item">
              <a href="#about" class="nav-link scroll-link">About</a>
            </li>

            <li class="nav-item">
              <a href="#services" class="nav-link scroll-link">Services</a>
            </li>

            <li class="nav-item">
              <a href="#portfolio" class="nav-link scroll-link">Portfolio</a>
            </li>

            <li class="nav-item">
              <a href="#testimonial" class="nav-link scroll-link">Testimonial</a>
          </li>

            <li class="nav-item">
              <a href="#contact" class="nav-link scroll-link">Contact</a>
            </li>


                 <li class="nav-item" style="color:white;"> 
                   <a href="checkout.php">
                          <?php 
                           
                                 if(!isset($_SESSION['customer_email'])){
                       
                                echo "<a href='checkout.php' style='color:white; font-size:14px; font-weight: bold;'> LOGIN </a>";

                               }else{

                                echo " <a href='logout.php'>LOGOUT </a> ";

                               }
                           
                           ?>
                     </a>
                   </li>

	                     

          </ul>
        </div>
        
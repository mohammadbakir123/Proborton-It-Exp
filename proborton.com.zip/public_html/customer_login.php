

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
    <meta name="description" content="Proborton is one of the leading Information Technology Solution Companies in Proborton specializes in development of complex software systems" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <meta property="og:image" content="https://www.proborton.com/images/d.jpg">
  <!-- Favicon -->
  <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" />
  <!-- AOS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
  <!-- Glidejs -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.core.css" />
  <style>







  </style>
  
  
  <script src="https://code.jquery.com/jquery-1.12.4.min.js" 
        integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" 
        crossorigin="anonymous">
</script>
<script src="jquery-image-scroll.js"></script>
  <!-- Custom Stylesheet -->
  <link rel="stylesheet" href="../styles.css" />
  <title>Proborton-IT-Exp</title>
   
    
    <!-- Bootstrap -->
    
</head>

<body>






<!-- header file -->




  <header id="header" class="header">
    <!-- Navigation -->
    <div class="navigation">
      <nav class="nav d-flex container">
        <div class="nav-header d-flex">
          
              <div class="logo" ><a href="index.php">
          <p>   Proborton-It-Exp  </p></a>
          </div>
          
          
         
          <div class="hamburger"><i class="fas fa-bars"></i></div>
        </div>

        <div class="nav-menu d-flex">
          <ul class="nav-list d-flex">
    
              <li class="nav-item"> 
             
              <a href="../customer_register.php" style="color:white; font-size:14px; font-weight: bold;" >SIGNUP</a>
              
              
            </li>
          
                   
          
          
          
          
          
            <li class="nav-item">
              <a href="../#about" style="color:white; font-size:14px; font-weight: bold;"  class="change">ABOUT</a>
            </li>

            <li class="nav-item">
              <a href="../#services" style="color:white; font-size:14px; font-weight: bold;"  class="change">SERVICES</a>
            </li>

            <li class="nav-item">
              <a href="../#portfolio" style="color:white; font-size:14px; font-weight: bold;" class="change">PORTFOLIO</a>
            </li>

            <li class="nav-item">
              <a href="../#testimonial" style="color:white; font-size:14px; font-weight: bold;" class="change">TESTIMONIAL</a>
          </li>

            <li class="nav-item">
              <a href="../#contact" style="color:white; font-size:14px; font-weight: bold;" class="change">CONTACT</a>
            </li>


                 <li class="nav-item" style="color:white;"> 
                   <a href="checkout.php">
                          <?php 
                           
                                 if(!isset($_SESSION['customer_email'])){
                       
                                echo "<a href='checkout.php' style='color:white; font-size:14px; font-weight: bold;'> LOGIN </a>";

                               }else{

                                echo " <a href='logout.php'>LOGOUT </a> ";

                               }
                           
                           ?>
                     </a>
                   </li>

	                     

          </ul>
        </div>
      </nav>
    </div>

    <!-- Hero Content -->
    
 
  <body>
        
    
               
            <div class="register">
			<h1>LOGIN</h1>
         
     
 
    
          
         <form method="post" id="flogin" action="checkout.php"><!-- form Begin -->
                    
        
            
               <input  type="text" name="customer_email" placeholder="Email" id="upass" required><br/>
          
          
          
          
          
              
               <input  type="password" name="customer_pass"  placeholder="Password" id="upass" required><br/>
      
        
           
            <input type="submit"="submit" name="login"  id="submit" value="Login" class="btn solid">
                   
         
              
          </form>
            
          
         </div>
       
 </div>




    
    <style>
   
* {
  	box-sizing: border-box;
  	font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
  	font-size: 16px;
  	-webkit-font-smoothing: antialiased;
  	-moz-osx-font-smoothing: grayscale;
}
body {
  	background-color: #435165;
  	margin: 0;
}
.register {
  	width: 340px;
  	background-color: #ffffff;
  	box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
  	margin: 100px auto;
  
}
.register h1 {
  	text-align: center;
  	color: #5b6574;
  	font-size: 24px;
  	padding: 20px 0 20px 0;
  	border-bottom: 1px solid #dee0e4;
  	margin-right:25px;
}
.register form {
  	display: flex;
  	flex-wrap: wrap;
  	justify-content: center;
  	padding-top: 20px;
}
.register form label {
  	display: flex;
  	justify-content: center;
  	align-items: center;
  	width: 50px;
 	height: 50px;
  	background-color: #3274d6;
  	color: #ffffff;
}


.register form input[type="password"], .register form input[type="text"], .register form input[type="email"] {
  	width: 310px;
  	height: 50px;
  	border: 1px solid #dee0e4;
  	margin-bottom: 20px;
  	padding: 0 15px;
}

.register form input[type="contact"], .register form input[type="text"], .register form input[type="contact"] {
  	width: 310px;
  	height: 50px;
  	border: 1px solid #dee0e4;
  	margin-bottom: 20px;
  	padding: 0 15px;
}

.register form input[type="address"], .register form input[type="text"], .register form input[type="address"] {
  	width: 310px;
  	height: 50px;
  	border: 1px solid #dee0e4;
  	margin-bottom: 20px;
  	padding: 0 15px;
}

.register form input[type="submit"] {
  	width: 100%;
  	padding: 15px;
  	margin-top: 20px;
  	background-color: #3274d6;
 	border: 0;
  	cursor: pointer;
  	font-weight: bold;
  	color: #ffffff;
  	transition: background-color 0.2s;
}
.register form input[type="submit"]:hover {
	background-color: #2868c7;
  	transition: background-color 0.2s;
}



     .change{
      padding: 1rem;
  color: var(--white);
  font-size: 1.4rem;
  font-weight: 600;
  text-transform: uppercase;
  transition: all 0.3s ease-in-out;
}
        
        .logo p{
            
            color:white;
            font-size:24px;
            font-weight:bold;
        }
    </style>
    
<script>
   $( window ).on( 'load', function(){
   $( '.screen' ).scrollImage();
   })
</script>


 <!-- AOS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
  <!-- Gsap -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>
  <!-- Glidejs -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/glide.min.js"></script>
  <!-- Custom Script -->
  <script src="./js/slider.js"></script>
  <script src="./js/index.js"></script>
  <script src="/path/to/cdn/jquery.min.js"></script>
<script src="/path/to/jquery.scrollimageinside.js"></script>

<script>
   $( window ).on( 'load', function(){
   $( '.screen' ).scrollImage();
   })
</script>


<script>
$('#example').scrollimageinside({
  speed: 900
});
</script>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

    
    
  </body>
</html>


<?php 

if(isset($_POST['login'])){
    
    $customer_email = $_POST['customer_email'];
    
    $customer_pass = $_POST['customer_pass'];
    
    $select_customer = "select * from customers where customer_email='$customer_email' AND customer_pass='$customer_pass'";
    
    $run_customer = mysqli_query($con,$select_customer);
    
    $get_ip = getRealIpUser();
    
    $check_customer = mysqli_num_rows($run_customer);
    
    $select_cart = "select * from cart where ip_add='$get_ip'";
    
    $run_cart = mysqli_query($con,$select_cart);
    
    $check_cart = mysqli_num_rows($run_cart);
    
    if($check_customer==0){
        
        echo "<script>alert('Your email or password is wrong')</script>";
        
        exit();
        
    }
    
    if($check_customer==1 AND $check_cart==0){
        
        $_SESSION['customer_email']=$customer_email;
        
       echo "<script>alert('Logged in')</script>"; 
        
       echo "<script>window.open('index.php','_self')</script>";
        
    }else{
        
        $_SESSION['customer_email']=$customer_email;
        
       echo "<script>alert('You are Logged in')</script>"; 
        
        
       echo "<script>window.open('customers/my_account.php?my_orders','_self')</script>";
        
    }
    
}

?>


<?php
// (A) PROCESS ORDER FORM
if (isset($_POST['name'])) { 
  require "process.php"; 
  echo $result == "" 
    ? "<div class='notify'>Thank You! We have received your order</div>" 
    : "<div class='notify'>$result</div>" ;
}
?>
 
<!-- (B) ORDER FORM -->
<form id="orderform" method="post" target="_self">
  <h1>Order Form</h1>
  <label for="name">Name:</label>
  <input type="text" name="name" required value="John Doe"/> 
  <label for="email">Email:</label>
  <input type="email" name="email" required value="john@doe.com"/> 
  <label for="tel">Telephone:</label>
  <input type="text" name="phone" required value="123-456-789"/> 
  <label for="qty">Quantity Needed:</label>
  <input type="amount" name="amount" required value="1"/> 
  <label for="notes">Additional Notes (if any):</label>
  <textarea name="address"></textarea>
  
  
  <input type="submit" value="Place Order"/>
</form>

<style>
    
    /* (A) ORDER FORM */
#orderform {
  padding: 15px;
  max-width: 400px;
  background: #f2f2f2;
}
#orderform h1 { margin: 0; }
#orderform label, #orderform input, #orderform textarea {
  display: block;
  box-sizing: border-box;
  width: 100%;
  padding: 10px;
  margin-top: 5px;
  resize: none;
}
#orderform input[type=submit] {
  margin-top: 10px;
  border: 0;
  background: #3f429c;
  color: #fff;
  cursor: pointer;
}

/* (B) NOTIFICATION BAR */
.notify {
  background: #d7ffe9;
  padding: 10px;
  margin-bottom: 10px;
  font-weight: bold;
}
/* (X) DOES NOT MATTER */
body, html, input, textarea {
  font-family: arial, sans-serif;
}
    
</style>
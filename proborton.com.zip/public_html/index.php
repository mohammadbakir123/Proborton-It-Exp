  

<?php
session_start();
error_reporting(0);


?>



 <?php 
 
 

 


include("includes/header.php");

 

include("includes/db_cons.php");
 ?>
 
 
 
	<?php 



if(isset($_GET['pro_id'])){
    
    $product_id = $_GET['pro_id'];
    
    $get_product = "select * from products where product_id='$product_id'";
    
    $run_product = mysqli_query($con,$get_product);
    
    $row_product = mysqli_fetch_array($run_product);
    
    $product_id = $row_product['product_id'];
    
    $pro_title = $row_product['product_title'];
    
    $pro_price = $row_product['product_price'];
    
    $pro_desc = $row_product['product_desc'];
    
    $pro_img1 = $row_product['product_img1'];
    
    $pro_img2 = $row_product['product_img2'];
    
    $pro_img3 = $row_product['product_img3'];
	
        
  
    
}

?>

 



<body>



  <!-- services -->
  <section class="section services" id="services">
    <div class="services-center container">
      <div class="top">
        <div class="subtitle">What we love to Do!</div>
        <h2>Our affordable services</h2>
        <p>
          Our expert team member has a lot of specialty, but what we love to
          do most of the time I a real question! Here are the things we really
          love to do!
        </p>
      </div>

      <div class="glide" id="glide1">
        <div class="glide__track" data-glide-el="track">
          <ul class="glide__slides">
            <li class="glide__slide">
              <div class="service">
                <span><i class="fas fa-mobile-alt"></i></span>
                <h4>Core PHP/Laravel  Theme</h4>
                <p>
                  We build  CORE PHP and laravel theme, maintaining all the server rules &
                  standard, which is 100% valid, SEO friendly.
                </p>
              </div>
            </li>
            <li class="glide__slide">
              <div class="service">
                <span><i class="fas fa-paint-brush"></i></span>
                <h4>PSD to Bootstarp</h4>
                <p>
                  Slicing PSD to Bootstarp /HTML/CSS/ with proper way is a very important
                  thing & we do it most efficient way.
                </p>
              </div>
            </li>
            <li class="glide__slide">
              <div class="service">
                <span><i class="far fa-heart"></i></span>
                <h4>20+ Payment Options for Your Customers</h4>
                <p>
                               Transform your business with
                            the best in class payment solution
                    Experience the all-in-one payments platform that boosts your business.
                </p>
              </div>
            </li>

            <li class="glide__slide">
              <div class="service">
                <span><i class="far fa-image"></i></span>
                <h4>Website design</h4>
                <p>
                  Design a website is a most important part of building a
                  website & we do it professionally.
                </p>
              </div>
            </li>
            <li class="glide__slide">
              <div class="service">
                <span><i class="fas fa-pencil-alt"></i></span>
                <h4>Custom WordPress</h4>
                <p>
                  WordPress is our love & we can build awesome custom made
                  website 
                </p>
              </div>
            </li>
          </ul>
        </div>

        <!-- Dots -->
        <div class="glide__bullets" data-glide-el="controls[nav]">
          <button class="glide__bullet" data-glide-dir="<<"></button>
          <button class="glide__bullet" data-glide-dir=">>"></button>
        </div>
      </div>
    </div>
  </section>

  <!-- Portfolio -->
  

  <section>
  

    
	   <div class="portfolio-container">
       
      
          
          <?php 
           
           getProduct();

           ?>
           
    
	    
   </div><!-- container Finish -->
		
		
 
  </section>

 <section class="section about" id="about">
    <div class="about-center container">
      <div class="left" data-aos="fade-right" data-aos-duration="2000">
        <div class="subtitle" style="color:green">Warm welcome!</div>
        <h2 class="title">Mohammad Bakir</h2>
        <p>
          in our team has a lot of awesome people who dedicate their time to
          make some creative things & us really proud of that. Mostly we do
          web design & development work based on PHP ,javascript,Jquery,HTML5,Bootstrap, Vue.js,CSS
        </p>
        <p class="top" >
          We are working with the CORE PHP ,Laravel , Node.js,Bootstrap, JavaScript,Jquery, s very beginning of the time. Our
          expert team is very well known, this framework. We love to build a
          website using WordPress.
        </p>

     
      </div>
      <div class="right-side" data-aos="fade-left" data-aos-duration="2000">
	  <a href="../index.php"> <img src="./images/profile1.jpg" alt="" /></a>
    
     
    </div>
  </section>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  

  <section class="section testimonials" id="testimonial">
    <div class="container">
      <div class="top">
        <div class="subtitle">Few words from clients</div>
        <h2 class="title" style="color:green">Testimonial</h2>
        <p>
          Clients are our assets & we always try to fulfill their requirements
          100%. We have lots of clients & most of them are very happy with us!
        </p>
      </div>

      <div class="glide" id="glide2">
        <div class="glide__track" data-glide-el="track">
          <ul class="glide__slides">
            <li class="glide__slide">
              <div class="testimonial">
                <span class="quote">&#8220;</span>
                <p>
                  I enjoyed working with
                  <span class="color">@CoderExperts Team</span>
                  very much. After explaining what I needed as giving a few
                  examples, they provided exactly what I needed.
                </p>
                <div class="bottom">
                  <div class="img-holder">
                    <img src="./images/test1.jpg" alt="" />
                  </div>
                  <div>
                    <h4>Samia Shahrin</h4>
                    <span>Designer</span>
                  </div>
                </div>
            </li>
            <li class="glide__slide">
              <div class="testimonial">
                <span class="quote">&#8220;</span>
                <p>
                  I enjoyed working with
                  <span class="color">@CoderExperts Team</span>
                  very much. After explaining what I needed as giving a few
                  examples, they provided exactly what I needed.
                </p>
                <div class="bottom">
                  <div class="img-holder">
                    <img src="./images/test2.jpg" alt="" />
                  </div>
                  <div>
                    <h4>Ponkoj Das</h4>
                    <span>Frontend Developer</span>
                  </div>
                </div>
              </div>
            </li>
            <li class="glide__slide">
              <div class="testimonial">
                <span class="quote">&#8220;</span>
                <p>
                  I enjoyed working with
                  <span class="color">@CoderExperts Team</span>
                  very much. After explaining what I needed as giving a few
                  examples, they provided exactly what I needed.
                </p>
                <div class="bottom">
                  <div class="img-holder">
                    <img src="./images/test3.jpg" alt="" />
                  </div>
                  <div>
                    <h4> Rasel Ahmed</h4>
                    <span>Content Writer</span>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>

        <!-- Arrows -->
        <div class="glide__arrows" data-glide-el="controls">
          <button class="glide__arrow glide__arrow--left" data-glide-dir="<"><i class="fas fa-angle-left"></i></button>
          <button class="glide__arrow glide__arrow--right" data-glide-dir=">"><i
              class="fas fa-angle-right"></i></button>
        </div>
      </div>
    </div>
  </section>

  <!-- Blog -->

  <!-- Contact -->
  <section class="section contact" id="contact">
    <div class="contact-center container">
      <div class="left" data-aos="fade-down-right" data-aos-duration="2000">
        <h2>Contact Us</h2>
        <p>
          Send your requirement using the form & our support team will get
          back to you as soon as possible. Please describe briefly everything
          you need & possibly send some example you like.
        </p>
        <p>
          Note: we can't spam you with lots of messages. We hate to send spam
          messages of our valuable clients.
        </p>
        <div class="bottom">
          <div>
            <span><i class="fas fa-map-marked-alt"></i></span>
            <h4>Location</h4>
            <small> Road : Shah Waliullah R/A
Word </br> No:6, Thana : Chandgaon  
, House:</br> Dr.Kamal Villa , Division: Chittagong,</br> Country: Bangladesh
</small>
          </div>
          <div>
            <span><i class="far fa-envelope-open"></i></span>
            <h4>Email</h4>
            <small> sayfshafi@gmail.com</small>
          </div>
        </div>
      </div>

      <div class="right" data-aos="fade-up-left" data-aos-duration="2000" >
 
 
   <form action="index.php" method="post"><!-- form Begin -->
          <div >
            <input type="text"  name="firstname" style="font-color:green;" placeholder="Name" />
            <input type="email" name="email" placeholder="E-mail" />
          </div>
          <textarea cols="48" rows="10" name="message"  placeholder="Message" ></textarea>
                     <div class="text-center"><!-- text-center Begin -->
                               
                               <button style="background-color:green" type="submit" name="submit" >
                               
                         Send Message
                               
                               </button>
                               
                           </div><!-- text-center Finish -->
           
           
           
           
           
           
           
           
           
        </form>
                               
                       <?php 
                       
                       if(isset($_POST['submit'])){
                           
                           /// Admin receives message with this ///
                           
                           $sender_name = $_POST['name'];
                           
                           $sender_email = $_POST['email'];
                           
                   
                           
                           $sender_message = $_POST['message'];
                           
                           $receiver_email = "sayfshafi@gmail.com";
                           
                           mail($receiver_email,$sender_name,$sender_message,$sender_email);
                           
                           /// Auto reply to sender with this ///
                           
                           $email = $_POST['email'];
                           
                           $subject = "Welcome to my website";
                           
                           $msg = "Thanks for sending us message. ASAP we will reply your message";
                           
                           $from = "MohammadBakirCSE@gmail.com";
                           
                           mail($email,$subject,$msg,$from);
                           
                           echo "<h1 align='center'> Your message has sent sucessfully </h2>";
                           
                       }
                       
                       ?>
        
        
        
        
      </div>
      
      
      
      
      
      
      
      
      
      
      
      
      
    </div>
  </section>








<style>
    

    
</style>








<?php include "counter.php"; ?>




  <!-- Footer -->
  <footer>
      

    <p> 2021 All right reserved!By Proborton.com </p>
    
  </footer>
  <!-- AOS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
  <!-- Gsap -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>
  <!-- Glidejs -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/glide.min.js"></script>
  <!-- Custom Script -->
  <script src="./js/slider.js"></script>
  <script src="./js/index.js"></script>
  <script src="/path/to/cdn/jquery.min.js"></script>
<script src="/path/to/jquery.scrollimageinside.js"></script>

<script>
   $( window ).on( 'load', function(){
   $( '.screen' ).scrollImage();
   })
</script>


<script>
$('#example').scrollimageinside({
  speed: 900
});
</script>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>


</body>

</html>
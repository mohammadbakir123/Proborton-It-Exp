  

<?php
session_start();
error_reporting(0);


?>





<?php include('includes/db_cons.php')?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
   <meta property="og:image" content="https://www.proborton.com/images/d.jpg">
  <!-- Favicon -->
  <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" />
  <!-- AOS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
  <!-- Glidejs -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.core.css" />
   <link rel="stylesheet" href="styles/style.css" />
    <link href="css/style.css" rel="stylesheet">    

  <link rel="stylesheet" href="styles/bootstrap-337.min">
  
      <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
  
    <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>
    
    
    
        <link rel="stylesheet" href="styles/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
</body>
  <style>







  </style>
  
  
  <script src="https://code.jquery.com/jquery-1.12.4.min.js" 
        integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" 
        crossorigin="anonymous">
</script>
<script src="jquery-image-scroll.js"></script>
  <!-- Custom Stylesheet -->
  <link rel="stylesheet" href="./styles.css" />
  <title>Proborton-IT-Exp</title>
</head>

<body>
   <div class="container">
          
               
               <ul class="breadcrumb">
                   <li>
                       <a href="../index.php">Home</a>
                   </li>
                   <li>
                          
                               
                                   
                             Transaction History
                                   
                              
                   </li>
              
                   
                   
                   
               </ul>
               
           </div>




<div class="status">
<h1>.Your Transaction Status</h1>

</div>
<div class="city">
<h2><?php
    
echo "<h1> Transaction success</h1>";

?></h2>
<p></p>
</div>

</html>
